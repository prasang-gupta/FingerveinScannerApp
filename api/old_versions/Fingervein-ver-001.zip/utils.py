import json
import os
import re

def get_data():
    if os.path.exists("datafile.json"):
        with open("datafile.json") as f:
            data = json.load(f)
        return data
    else:
        data = []
        return data

def put_data(data):
    with open("datafile.json", "w") as f:
        json.dump(data, f, indent=4)

def get_available_id():
    avail_id = -1
    new_avail_id = []
    if os.path.exists("availids.txt"):
        with open("availids.txt") as f:
            for line in f:
                if avail_id == -1:
                    avail_id = line
                    continue
                new_avail_id.append(line)
        if avail_id != -1:
            with open("availids.txt", "w") as f:
                for id in new_avail_id:
                    f.write(id)
        return int(avail_id)
    else:
        return -1

def get_new_id():
    avail_id = get_available_id()
    if avail_id != -1:
        return avail_id
    data = get_data()
    return len(data)

def get_user_from_finger(val):
    data =  get_data()
    for d in data:
        if d["fingertemplate"] == val:
            return d["id"]
    return -1

def check_email_exist(val):
    data = get_data()
    for d in data:
        if d["email"] == val:
            return 1
    return 0

def add_datapoint(newval):
    if check_email_exist(newval["email"]):
        return 0
    data = get_data()
    data.append(newval)
    put_data(data)
    return 1

def delete_email(val):
    data = get_data()
    
    newdata = []
    flag = 0
    for d in data:
        if d["email"] == val:
            flag = 1
            if os.path.exists("availids.txt"):
                with open("availids.txt", "a") as f:
                    f.write(str(d["id"]) + "\n")
            else:
                with open("availids.txt", "w") as f:
                    f.write(str(d["id"]) + "\n")
            continue
        newdata.append(d)
    
    put_data(newdata)
    return flag

def remove_files():
    if os.path.exists("datafile.json"):
        os.remove("datafile.json")
    if os.path.exists("availids.txt"):
        os.remove("availids.txt")