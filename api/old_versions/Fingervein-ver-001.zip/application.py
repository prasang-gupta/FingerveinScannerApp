from flask import Flask, jsonify, request, abort
import json
from utils import get_new_id, add_datapoint, get_user_from_finger, check_email_exist, delete_email, remove_files

application = Flask(__name__)

@application.route('/')
def homepage():
    return "RESTFUL API for FingerVein Running"

@application.route('/enroll', methods=['POST'])
def enroll():
    if not request.json or "first" not in request.json \
                        or "last" not in request.json \
                        or "email" not in request.json \
                        or "fingertemplate" not in request.json \
                        or "fingerverificationtemplate" not in request.json:
        return jsonify({"success" : 0,
                        "error" : "No / Incomplete data given for enrollment"}), 400
    
    new_user = {
        "id" : get_new_id(),
        "first" : request.json["first"],
        "last" : request.json["last"],
        "email" : request.json["email"],
        "fingertemplate" : request.json["fingertemplate"],
        "fingerverificationtemplate" : request.json["fingerverificationtemplate"]
    }
    if not add_datapoint(new_user):
        return jsonify({"success" : 0,
                        "error" : "User already exists"}), 402
    return jsonify({"success" : 1}), 200

@application.route('/authenticate', methods=['POST'])
def authentication():
    if not request.json or "fingertemplate" not in request.json:
        return jsonify({"success" : 0,
                        "error" : "No finger template provided"}), 400
    
    fingercode = request.json["fingertemplate"]
    response = get_user_from_finger(fingercode)
    if response == -1:
        return jsonify({"success" : 0,
                        "error" : "Finger template not authenticated"}), 403
    return jsonify({"success" : 1,
                    "ID" : response}), 200

@application.route('/checkexists', methods=['POST'])
def checkexists():
    if not request.json or "email" not in request.json:
        return jsonify({"success" : 0,
                        "error" : "No email provided"}), 400

    email = request.json["email"]
    response = check_email_exist(email)
    if response:
        return jsonify({"success" : response}), 200
    return jsonify({"success" : response}), 401

@application.route('/delete', methods=['POST'])
def delete():
    if not request.json or "email" not in request.json:
        return jsonify({"success" : 0,
                        "error" : "No email provided"}), 400

    email = request.json["email"]
    response = delete_email(email)
    if response:
        return jsonify({"success" : response}), 200
    return jsonify({"success" : response,
                    "error" : "No entry found with the given email"}), 405

@application.route('/reset', methods=['GET'])
def reset():
    remove_files()
    return jsonify({"success" : 1}), 200

if __name__ == '__main__':
    application.run(host="0.0.0.0", port=80)